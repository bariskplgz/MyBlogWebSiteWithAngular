import { Component, Input} from '@angular/core';
import { Article } from '../../models/article';
import { Router, ActivatedRoute } from "@angular/router";
import { ArticleService } from '../../services/article.service';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-articles',
  standalone: true,
  imports: [RouterModule,CommonModule],
  templateUrl: './articles.component.html',
  styleUrl: './articles.component.css'
})
export class ArticlesComponent {
  @Input() totalCount: number = 0;
  @Input() articles: Article[] = [];
  @Input() page: number = 1;
  @Input() pageSize: number = 10;

  default_article: string = "assets/article_empty.jpg";

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private articleService: ArticleService
  ) {}


  pageChanged(event : any) {
    this.page = event;
  }
}
